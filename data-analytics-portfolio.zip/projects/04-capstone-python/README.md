# Python Flight Fare Prediction
**Question:** What decision are we enabling?

## Data
- Source, date pulled, sample size
- Data dictionary (columns & meanings)

## Method
- Cleaning steps (bullets)
- Key SQL/Excel/Tableau/Python techniques

## Findings
- 3–5 bullets with concrete metrics

## Visuals
- Dashboard/screenshots

## Reproduce
- Files to run
- Any credentials/none

## Next Steps
- What you’d do with more time/data
